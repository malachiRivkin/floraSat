#include "submsg_callback.pb.h"

SubMsg1 submsg1_zero = SubMsg1_init_zero;
SubMsg1 submsg1_def = SubMsg1_init_default;
SubMsg2 submsg2_zero = SubMsg2_init_zero;
SubMsg2 submsg2_def = SubMsg2_init_default;
SubMsgCB submsgcb_zero = SubMsgCB_init_zero;
SubMsgCB submsgcb_def = SubMsgCB_init_default;

int main()
{
    return 0;
}

